﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Mail.Models;
using MimeKit;
using MailKit.Net.Smtp;
using System.IO;
using System.Net;

namespace Mail.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }


        [HttpGet]
        public IActionResult Email()
        {
            var message = new MimeMessage();
            message.From.Add(new MailboxAddress("Test Project", "your@gmail.com"));
            message.To.Add(new MailboxAddress("pritom", "To@gmail.com"));
            message.Subject = "Hi,this is demo email";
            message.Body = new TextPart("plain")
            {
                Text = "Hello,My First Demo Mail it is.Thanks",
            };
            using (var client = new SmtpClient())
            {
                client.Connect("smtp.gmail.com", 587, false);
                client.Authenticate("Your@gmail.com", "YourPassword");

                client.Send(message);
                client.Disconnect(true);
            }
            return View();
            
        }



        public IActionResult AEmail()
        {
            var email = User.Identity.Name;
            var message = new MimeMessage();
            message.From.Add(new MailboxAddress("Test Project",
            "your@gmail.com"));
            message.To.Add(new MailboxAddress("pritom", "To@gmail.com"));
            message.Subject = "Hi,this is demo email";
            message.Body = new TextPart("plain")
            {
                Text = "Hello,My First Demo Mail it is.Thanks",
            };
            //add attach
            MemoryStream memoryStream = new MemoryStream();
            BodyBuilder bb = new BodyBuilder();
            using (var wc = new WebClient())
            {
                //bb.Attachments.Add("attachmentName",
                //wc.DownloadData("wwwroot/Images/H.pdf"));
                bb.Attachments.Add("Email.pdf",
                wc.DownloadData("wwwroot/Email.pdf"));
                //bb.Attachments.Add("H.pdf", new MemoryStream());
            }
            message.Body = bb.ToMessageBody();
            //end attach
            using (var client = new SmtpClient())
            {
                client.Connect("smtp.gmail.com", 587, false);
                client.Authenticate("your@gmail.com",
                "yourpassword");
                client.Send(message);
                client.Disconnect(true);
            }
            //email end
            return View("Email");
        }
    }
}
